
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.17.3'
version = '1.17.3'
full_version = '1.17.3'
git_revision = 'ff3df08438d570b0ccdda3f8a008278d8a4ad394'
release = True

if not release:
    version = full_version
